#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[50];
    char idType[50];
    char dataType[50];
    char scope[50];
    char value[50];
} SymbolTable;

int main() {
    FILE *inputFile = fopen("input.txt", "r");
    FILE *outputFile = fopen("output1.txt", "w");
    if (inputFile == NULL || outputFile == NULL) {
        fprintf(stderr, "Could not open the file\n");
        return 1;
    }

    char tokenType[20], tokenValue[20];

    while (fscanf(inputFile, " [%[^]]] [%[^]]]", tokenType, tokenValue) != EOF) {
        if (strcmp(tokenType, "id") != 0) {
            fprintf(outputFile, "[%s] [%s] ", tokenType, tokenValue);
        }
    }

    fclose(inputFile);
    fclose(outputFile);

    inputFile = fopen("output1.txt", "r");
    SymbolTable symbols[10]; 
    int count = 0;

    while (fscanf(inputFile, " [%[^]]] [%[^]]]", tokenType, tokenValue) != EOF) {
        if (strcmp(tokenType, "id") == 0) {
            strcpy(symbols[count].name, tokenValue);
            strcpy(symbols[count].idType,"var");
            strcpy(symbols[count].scope ,"global"); 
            count++;
        }
        else if(strcmp(tokenType,"num")==0){
            strcpy(symbols[count-1].value ,tokenValue);
        }
        else if(strcmp(tokenType,"kw")==0){
            strcpy(symbols[count-1].dataType ,tokenValue);
        }
     }

     fclose(inputFile);

     printf("Symbol Table:\n");
     printf("Name\tId Type\tData Type\tScope\tValue\n");

     for(int i=0; i<count; i++) {
         printf("%s\t%s\t%s\t%s\t%s\n", symbols[i].name,symbols[i].idType,symbols[i].dataType,symbols[i].scope,symbols[i].value);
     }

     return 0;
}
