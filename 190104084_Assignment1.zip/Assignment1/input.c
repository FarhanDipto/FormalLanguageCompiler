#include <stdio.h>
int main(void)
{
    // Single Line Comment
    printf("Hello");
    /* Multi
    Line

    Comment

    */
    printf("World");
    return 0;
}